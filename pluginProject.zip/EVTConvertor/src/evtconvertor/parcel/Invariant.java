package evtconvertor.parcel;

public class Invariant {
	
	private String predicate;
	
	public Invariant(String predicate) {
		this.predicate = predicate;
	}

	public String getPredicate() {
		return predicate;
	}

	public void setPredicate(String predicate) {
		this.predicate = predicate;
	}
	
	
	
}
