package evtconvertor.parcel;

import java.awt.Component;
import java.util.ArrayList;

public class Event {
	
	private String name;
	private ArrayList<EventComponent> components;
	private int startLine;
	private int endLine;
	
	public Event(String name, int startLine, int endLine) {
		this.name = name;
		this.startLine = startLine;
		this.endLine = endLine;
		components = new ArrayList<EventComponent>();
	}
	
	public Event(String name, ArrayList<EventComponent> components){
		this.name = name;
		this.components = components;
	}
	
	public void addComponent(EventComponent component){
		components.add(component);
	}

	@Override
	public String toString() {
		return "Event [name=" + name + ", components=" + components + ", startLine=" + startLine + ", endLine="
				+ endLine + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<EventComponent> getComponents() {
		return components;
	}

	public void setComponents(ArrayList<EventComponent> components) {
		this.components = components;
	}

	public int getStartLine() {
		return startLine;
	}

	public void setStartLine(int startLine) {
		this.startLine = startLine;
	}

	public int getEndLine() {
		return endLine;
	}

	public void setEndLine(int endLine) {
		this.endLine = endLine;
	}
	
}
