package evtconvertor.specs;

public class AndSpec extends Spec{

	public AndSpec(String type, String name, String parentSpecString, String operator, int startLine, int endLine) {
		super(type, name, parentSpecString, operator, endLine, endLine);
	}	
	
}
