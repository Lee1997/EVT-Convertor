package evtconvertor.specs;

import java.util.ArrayList;

import evtconvertor.parcel.Event;

public class AndSpec extends Spec{
	
	private String logic;
	private String name;
	private String operator;
	private int startLine;
	private int endLine;
	private Spec parentSpec;
	private String parentSpecString;
	private ArrayList<Event> events;
	private MachineSpec firstParent;
	private MachineSpec secondParent;
	
	public AndSpec(String logic, String name, String parentSpecString, String operator, int startLine, int endLine, MachineSpec firstParent, MachineSpec secondParent) {
		super(logic, name, parentSpecString, operator, startLine, endLine);		
		this.logic = logic.trim();
		this.name = name.trim();
		this.operator = operator.trim();
		this.startLine = startLine;
		this.endLine = endLine;
		this.parentSpecString = parentSpecString;
		this.firstParent = firstParent;
		this.secondParent = secondParent;
		this.events = new ArrayList<Event>();
	}
	
	public void addEvent(Event event){
		events.add(event);
	}
	
	public ArrayList<Event> getEvents(){
		return events;
	}

	public MachineSpec getFirstParent() {
		return firstParent;
	}

	public void setFirstParent(MachineSpec firstParent) {
		this.firstParent = firstParent;
	}

	public MachineSpec getSecondParent() {
		return secondParent;
	}

	public void setSecondParent(MachineSpec secondParent) {
		this.secondParent = secondParent;
	}
}
